﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Properties.cs" company="US Naval Academy Alumni Association & Foundation">
//   2016
// </copyright>
// <summary>
//   Defines the Properties type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;
    
    [Serializable]
    public class BlackbaudArguments
    {
     public string ExampleProperty { get; set; }
    }
}